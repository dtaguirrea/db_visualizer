"""Cliente para HURIDOCS pdf-document-layout-analysis."""
from pathlib import Path
import os
import requests
from pypdf import PdfReader

import config

_EXCLUDED_SEGMENT_TYPES = {"Page header", "Page footer"}


class OcrServiceError(Exception):
    pass


def _post_pdf(endpoint: str, file_path: str, data: dict):
    url = f"{config.OCR_SERVICE_URL}{endpoint}"
    try:
        with open(file_path, "rb") as file_handle:
            response = requests.post(
                url,
                files={"file": (Path(file_path).name, file_handle, "application/pdf")},
                data=data,
                timeout=config.OCR_TIMEOUT_SECONDS,
            )
    except requests.exceptions.ConnectionError as exc:
        raise OcrServiceError("No fue posible conectar con el servicio OCR.") from exc
    except requests.exceptions.Timeout as exc:
        raise OcrServiceError("El procesamiento OCR excedió el tiempo máximo configurado.") from exc
    except requests.exceptions.RequestException as exc:
        raise OcrServiceError(f"Error de comunicación con el servicio OCR: {exc}") from exc

    if response.status_code != 200:
        detail = response.text[:400].strip()
        if endpoint == "/ocr" and data.get("language") == "pt":
            detail += (
                " Portugués se envía como pt (código correcto de HURIDOCS). "
                "Comprueba que tesseract --list-langs en ocr_service incluya por; "
                "si está instalado, revisa los logs del servicio para identificar la causa."
            )
        suffix = f" Detalle: {detail}" if detail else ""
        raise OcrServiceError(f"El servicio OCR respondió con código {response.status_code}.{suffix}")
    return response


def create_searchable_pdf(input_path: str, output_path: str, language: str | None = None) -> str:
    """Genera un PDF buscable con capa de texto mediante POST /ocr."""
    response = _post_pdf("/ocr", input_path, {
        "language": language or config.OCR_LANGUAGE,
        "rotate_pages": str(config.OCR_ROTATE_PAGES).lower(),
        "deskew": str(config.OCR_DESKEW).lower(),
    })
    content = response.content
    if not content.startswith(b"%PDF"):
        raise OcrServiceError("El servicio OCR no devolvió un PDF válido.")

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    temp_path = output.with_suffix(output.suffix + ".tmp")
    temp_path.write_bytes(content)
    os.replace(temp_path, output)
    return str(output)


def extract_text_from_pdf(file_path: str) -> str:
    """Extrae texto estructurado del PDF ya OCRizado para búsqueda."""
    response = _post_pdf("/text", file_path, {
        "fast": "true" if config.OCR_USE_FAST_MODE else "false",
        "types": "all",
    })
    try:
        segments = response.json()
    except ValueError as exc:
        raise OcrServiceError("El servicio OCR devolvió una respuesta de texto inválida.") from exc

    if isinstance(segments, dict) and "text" in segments:
        return segments["text"] or ""
    if not isinstance(segments, list):
        return str(segments)
    return "\n\n".join(
        segment.get("text", "").strip()
        for segment in segments
        if segment.get("type") not in _EXCLUDED_SEGMENT_TYPES and segment.get("text", "").strip()
    )


def extract_text_locally(file_path: str) -> str:
    """Lee la capa de texto del PDF OCR sin ejecutar análisis de layout remoto."""
    reader = PdfReader(file_path)
    pages = []
    for page in reader.pages:
        page_text = (page.extract_text() or "").strip()
        if page_text:
            pages.append(page_text)
    return "\n\n".join(pages)


def process_pdf(
    input_path: str,
    output_path: str,
    language: str | None = None,
) -> tuple[str, str]:
    searchable_pdf = create_searchable_pdf(input_path, output_path, language=language)
    if config.OCR_TEXT_EXTRACTION_MODE == "disabled":
        extracted_text = ""
    elif config.OCR_TEXT_EXTRACTION_MODE == "huridocs":
        extracted_text = extract_text_from_pdf(searchable_pdf)
    else:
        extracted_text = extract_text_locally(searchable_pdf)
    return searchable_pdf, extracted_text


def check_service_health() -> bool:
    try:
        response = requests.get(f"{config.OCR_SERVICE_URL}/info", timeout=5)
        return response.status_code == 200
    except requests.exceptions.RequestException:
        return False

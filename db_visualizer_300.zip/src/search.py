"""Búsqueda global de documentos y tablas personalizadas."""
from __future__ import annotations

from sqlalchemy import inspect, text
from sqlalchemy.engine import Connection

import config
from src.database import get_dynamic_column_metadata, get_primary_key_column, is_postgres
from src.dynamic_tables import list_registered_tables

AUDIT_COLUMNS = {"created_by", "created_at", "updated_by", "updated_at"}


def _quote_identifier(conn: Connection, identifier: str) -> str:
    return conn.dialect.identifier_preparer.quote(identifier)


def _like_pattern(query: str) -> str:
    escaped = query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


def search_documents(conn: Connection, query: str, limit: int | None = None,
                     *, author: str = "", date_from=None, date_to=None) -> list[dict]:
    from src.document_service import normalize_document_date
    from src.field_values import date_bounds
    date_from = date_bounds(normalize_document_date(date_from))[0]
    date_to = date_bounds(normalize_document_date(date_to))[1]
    if date_from and date_to and date_from > date_to:
        raise ValueError("La fecha inicial no puede ser posterior a la final.")
    query = (query or "").strip()
    author = (author or "").strip()
    if not (query or author or date_from or date_to):
        return []
    limit = limit or config.SEARCH_RESULT_LIMIT
    params = {"query": query, "pattern": _like_pattern(query), "limit": limit}
    params.update(author=_like_pattern(author), date_from=date_from, date_to=date_to)

    common_select = '''
        SELECT document_id, title, author, source_reference, document_date, original_format,
               ocr_status, ocr_text, created_by, created_at
        FROM (
            SELECT * FROM document_records
            WHERE LOWER(COALESCE(author, '')) LIKE LOWER(:author) ESCAPE '\\'
              AND (CAST(:date_from AS TEXT) IS NULL OR document_date_end >= :date_from)
              AND (CAST(:date_to AS TEXT) IS NULL OR document_date_start <= :date_to)
        ) AS filtered_documents
    '''
    if is_postgres(conn):
        rows = conn.execute(text(common_select + '''
            WHERE
                to_tsvector(
                    'spanish',
                    COALESCE(title, '') || ' ' ||
                    COALESCE(source_reference, '') || ' ' ||
                    COALESCE(document_date, '') || ' ' ||
                    COALESCE(original_format, '') || ' ' ||
                    COALESCE(ocr_text, '')
                ) @@ websearch_to_tsquery('spanish', :query)
                OR LOWER(COALESCE(title, '')) LIKE LOWER(:pattern) ESCAPE '\\'
                OR LOWER(COALESCE(author, '')) LIKE LOWER(:pattern) ESCAPE '\\'
                OR LOWER(COALESCE(source_reference, '')) LIKE LOWER(:pattern) ESCAPE '\\'
                OR LOWER(COALESCE(document_date, '')) LIKE LOWER(:pattern) ESCAPE '\\'
                OR LOWER(COALESCE(original_format, '')) LIKE LOWER(:pattern) ESCAPE '\\'
                OR LOWER(COALESCE(ocr_text, '')) LIKE LOWER(:pattern) ESCAPE '\\'
            ORDER BY
                CASE
                    WHEN LOWER(COALESCE(title, '')) LIKE LOWER(:pattern) ESCAPE '\\' THEN 0
                    WHEN LOWER(COALESCE(source_reference, '')) LIKE LOWER(:pattern) ESCAPE '\\' THEN 1
                    ELSE 2
                END,
                document_id DESC
            LIMIT :limit
        '''), params).mappings().all()
    else:
        rows = conn.execute(text(common_select + '''
            WHERE
                LOWER(COALESCE(title, '')) LIKE LOWER(:pattern) ESCAPE '\\'
                OR LOWER(COALESCE(author, '')) LIKE LOWER(:pattern) ESCAPE '\\'
                OR LOWER(COALESCE(source_reference, '')) LIKE LOWER(:pattern) ESCAPE '\\'
                OR LOWER(COALESCE(document_date, '')) LIKE LOWER(:pattern) ESCAPE '\\'
                OR LOWER(COALESCE(original_format, '')) LIKE LOWER(:pattern) ESCAPE '\\'
                OR LOWER(COALESCE(ocr_text, '')) LIKE LOWER(:pattern) ESCAPE '\\'
            ORDER BY document_id DESC
            LIMIT :limit
        '''), params).mappings().all()
    return [dict(row) for row in rows]


def search_dynamic_tables(conn: Connection, query: str, limit: int | None = None) -> list[dict]:
    query = (query or "").strip()
    if not query:
        return []
    limit = limit or config.SEARCH_RESULT_LIMIT
    pattern = _like_pattern(query)
    results: list[dict] = []
    inspector = inspect(conn)
    existing_tables = set(inspector.get_table_names())

    for registry_row in list_registered_tables(conn):
        table_name = registry_row["table_name"]
        if table_name not in existing_tables:
            continue
        pk_column = get_primary_key_column(conn, table_name)
        metadata = get_dynamic_column_metadata(conn, table_name)
        physical_names = {column["name"] for column in inspector.get_columns(table_name)}
        searchable_columns = list(dict.fromkeys(
            item["column_name"] for item in metadata
            if item["column_name"] not in AUDIT_COLUMNS and item["column_name"] in physical_names
        ))
        if not searchable_columns:
            continue

        q_table = _quote_identifier(conn, table_name)
        q_pk = _quote_identifier(conn, pk_column)
        conditions = []
        for column_name in searchable_columns:
            q_col = _quote_identifier(conn, column_name)
            if is_postgres(conn):
                conditions.append(f"CAST({q_col} AS TEXT) ILIKE :pattern ESCAPE '\\'")
            else:
                conditions.append(f"LOWER(CAST({q_col} AS TEXT)) LIKE LOWER(:pattern) ESCAPE '\\'")

        remaining = max(0, limit - len(results))
        if remaining == 0:
            break
        q_columns = ", ".join(_quote_identifier(conn, col) for col in searchable_columns)
        sql = f'''
            SELECT {q_pk}, {q_columns}
            FROM {q_table}
            WHERE {' OR '.join(conditions)}
            ORDER BY {q_pk} DESC
            LIMIT :limit
        '''
        rows = conn.execute(text(sql), {"pattern": pattern, "limit": remaining}).mappings().all()
        for row in rows:
            values = []
            for column_name in searchable_columns:
                value = row.get(column_name)
                if value is not None and query.casefold() in str(value).casefold():
                    values.append(f"{column_name}: {value}")
            if not values:
                values = [
                    f"{column_name}: {row.get(column_name)}"
                    for column_name in searchable_columns
                    if row.get(column_name) is not None
                ][:3]
            results.append({
                "table_name": table_name,
                "description": registry_row.get("description"),
                "record_id": row[pk_column],
                "matched_values": values[:5],
            })
            if len(results) >= limit:
                break
    return results


def global_search(conn: Connection, query: str) -> dict[str, list[dict]]:
    return {
        "documents": search_documents(conn, query),
        "tables": search_dynamic_tables(conn, query),
    }
